```python

```


```python
import pandas as pd
```


```python
df = pd.read_csv('netflix_titles.csv')
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>show_id</th>
      <th>type</th>
      <th>title</th>
      <th>director</th>
      <th>cast</th>
      <th>country</th>
      <th>date_added</th>
      <th>release_year</th>
      <th>rating</th>
      <th>duration</th>
      <th>listed_in</th>
      <th>description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>s1</td>
      <td>Movie</td>
      <td>Dick Johnson Is Dead</td>
      <td>Kirsten Johnson</td>
      <td>NaN</td>
      <td>United States</td>
      <td>September 25, 2021</td>
      <td>2020</td>
      <td>PG-13</td>
      <td>90 min</td>
      <td>Documentaries</td>
      <td>As her father nears the end of his life, filmm...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>s2</td>
      <td>TV Show</td>
      <td>Blood &amp; Water</td>
      <td>NaN</td>
      <td>Ama Qamata, Khosi Ngema, Gail Mabalane, Thaban...</td>
      <td>South Africa</td>
      <td>September 24, 2021</td>
      <td>2021</td>
      <td>TV-MA</td>
      <td>2 Seasons</td>
      <td>International TV Shows, TV Dramas, TV Mysteries</td>
      <td>After crossing paths at a party, a Cape Town t...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>s3</td>
      <td>TV Show</td>
      <td>Ganglands</td>
      <td>Julien Leclercq</td>
      <td>Sami Bouajila, Tracy Gotoas, Samuel Jouy, Nabi...</td>
      <td>NaN</td>
      <td>September 24, 2021</td>
      <td>2021</td>
      <td>TV-MA</td>
      <td>1 Season</td>
      <td>Crime TV Shows, International TV Shows, TV Act...</td>
      <td>To protect his family from a powerful drug lor...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>s4</td>
      <td>TV Show</td>
      <td>Jailbirds New Orleans</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>September 24, 2021</td>
      <td>2021</td>
      <td>TV-MA</td>
      <td>1 Season</td>
      <td>Docuseries, Reality TV</td>
      <td>Feuds, flirtations and toilet talk go down amo...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>s5</td>
      <td>TV Show</td>
      <td>Kota Factory</td>
      <td>NaN</td>
      <td>Mayur More, Jitendra Kumar, Ranjan Raj, Alam K...</td>
      <td>India</td>
      <td>September 24, 2021</td>
      <td>2021</td>
      <td>TV-MA</td>
      <td>2 Seasons</td>
      <td>International TV Shows, Romantic TV Shows, TV ...</td>
      <td>In a city of coaching centers known to train I...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>8802</th>
      <td>s8803</td>
      <td>Movie</td>
      <td>Zodiac</td>
      <td>David Fincher</td>
      <td>Mark Ruffalo, Jake Gyllenhaal, Robert Downey J...</td>
      <td>United States</td>
      <td>November 20, 2019</td>
      <td>2007</td>
      <td>R</td>
      <td>158 min</td>
      <td>Cult Movies, Dramas, Thrillers</td>
      <td>A political cartoonist, a crime reporter and a...</td>
    </tr>
    <tr>
      <th>8803</th>
      <td>s8804</td>
      <td>TV Show</td>
      <td>Zombie Dumb</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>July 1, 2019</td>
      <td>2018</td>
      <td>TV-Y7</td>
      <td>2 Seasons</td>
      <td>Kids' TV, Korean TV Shows, TV Comedies</td>
      <td>While living alone in a spooky town, a young g...</td>
    </tr>
    <tr>
      <th>8804</th>
      <td>s8805</td>
      <td>Movie</td>
      <td>Zombieland</td>
      <td>Ruben Fleischer</td>
      <td>Jesse Eisenberg, Woody Harrelson, Emma Stone, ...</td>
      <td>United States</td>
      <td>November 1, 2019</td>
      <td>2009</td>
      <td>R</td>
      <td>88 min</td>
      <td>Comedies, Horror Movies</td>
      <td>Looking to survive in a world taken over by zo...</td>
    </tr>
    <tr>
      <th>8805</th>
      <td>s8806</td>
      <td>Movie</td>
      <td>Zoom</td>
      <td>Peter Hewitt</td>
      <td>Tim Allen, Courteney Cox, Chevy Chase, Kate Ma...</td>
      <td>United States</td>
      <td>January 11, 2020</td>
      <td>2006</td>
      <td>PG</td>
      <td>88 min</td>
      <td>Children &amp; Family Movies, Comedies</td>
      <td>Dragged from civilian life, a former superhero...</td>
    </tr>
    <tr>
      <th>8806</th>
      <td>s8807</td>
      <td>Movie</td>
      <td>Zubaan</td>
      <td>Mozez Singh</td>
      <td>Vicky Kaushal, Sarah-Jane Dias, Raaghav Chanan...</td>
      <td>India</td>
      <td>March 2, 2019</td>
      <td>2015</td>
      <td>TV-14</td>
      <td>111 min</td>
      <td>Dramas, International Movies, Music &amp; Musicals</td>
      <td>A scrappy but poor boy worms his way into a ty...</td>
    </tr>
  </tbody>
</table>
<p>8807 rows × 12 columns</p>
</div>




```python
print(df.head())
```

      show_id     type                  title         director  \
    0      s1    Movie   Dick Johnson Is Dead  Kirsten Johnson   
    1      s2  TV Show          Blood & Water              NaN   
    2      s3  TV Show              Ganglands  Julien Leclercq   
    3      s4  TV Show  Jailbirds New Orleans              NaN   
    4      s5  TV Show           Kota Factory              NaN   
    
                                                    cast        country  \
    0                                                NaN  United States   
    1  Ama Qamata, Khosi Ngema, Gail Mabalane, Thaban...   South Africa   
    2  Sami Bouajila, Tracy Gotoas, Samuel Jouy, Nabi...            NaN   
    3                                                NaN            NaN   
    4  Mayur More, Jitendra Kumar, Ranjan Raj, Alam K...          India   
    
               date_added  release_year rating   duration  \
    0  September 25, 2021          2020  PG-13     90 min   
    1  September 24, 2021          2021  TV-MA  2 Seasons   
    2  September 24, 2021          2021  TV-MA   1 Season   
    3  September 24, 2021          2021  TV-MA   1 Season   
    4  September 24, 2021          2021  TV-MA  2 Seasons   
    
                                               listed_in  \
    0                                      Documentaries   
    1    International TV Shows, TV Dramas, TV Mysteries   
    2  Crime TV Shows, International TV Shows, TV Act...   
    3                             Docuseries, Reality TV   
    4  International TV Shows, Romantic TV Shows, TV ...   
    
                                             description  
    0  As her father nears the end of his life, filmm...  
    1  After crossing paths at a party, a Cape Town t...  
    2  To protect his family from a powerful drug lor...  
    3  Feuds, flirtations and toilet talk go down amo...  
    4  In a city of coaching centers known to train I...  
    


```python
import matplotlib.pyplot as plt
import seaborn as sns
```

## Visualizing the Distribution of Genres


```python
df['genre'] = df['listed_in'].str.split(',').apply(lambda x: x[0].strip())
```


```python
genre_counts = df['genre'].value_counts()
```


```python
plt.figure(figsize=(12,6))
sns.barplot(x=genre_counts.index, y=genre_counts.values, palette='viridis')
plt.xticks(rotation=90)
plt.title('Distribution of Genres in Netflix Dataset', fontsize=16)
plt.xlabel('Genre')
plt.ylabel('Number of Movies/Shows')
plt.tight_layout()
plt.show()
```

    C:\Users\ANIKET\AppData\Local\Temp\ipykernel_11708\4158821952.py:2: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x=genre_counts.index, y=genre_counts.values, palette='viridis')
    


    
![png](output_9_1.png)
    


##  Average Rating by Genre


```python
print(df.dtypes)
```

    show_id          object
    type             object
    title            object
    director         object
    cast             object
    country          object
    date_added       object
    release_year      int32
    rating          float64
    duration         object
    listed_in        object
    description      object
    genre            object
    dtype: object
    


```python
df['rating'] = pd.to_numeric(df['rating'], errors='coerce')
```


```python
mean_rating = df['rating'].mean()
print(mean_rating)
```

    nan
    


```python
average_rating_by_genre = df.groupby('genre')['rating'].mean().sort_values(ascending=False)
plt.figure(figsize=(12,6))
sns.barplot(x=average_rating_by_genre.index, y=average_rating_by_genre.values, palette='coolwarm')
plt.xticks(rotation=90)
plt.title('Average Rating by Genre', fontsize=16)
plt.xlabel('Genre')
plt.ylabel('Average Rating')
plt.tight_layout()
plt.show()
```

    C:\Users\ANIKET\AppData\Local\Temp\ipykernel_11708\1064763942.py:3: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x=average_rating_by_genre.index, y=average_rating_by_genre.values, palette='coolwarm')
    


    
![png](output_14_1.png)
    


## Top 10 Most Popular Movies/TV Shows Based on Rating


```python
top_10_rated = df[['title', 'rating']].dropna().sort_values(by='rating', ascending=False).head(10)
plt.figure(figsize=(10,6))
sns.barplot(x=top_10_rated['title'], y=top_10_rated['rating'], palette='magma')
plt.xticks(rotation=90)
plt.title('Top 10 Most Rated Movies/TV Shows on Netflix', fontsize=16)
plt.xlabel('Title')
plt.ylabel('Rating')
plt.tight_layout()
plt.show()
```


    
![png](output_16_0.png)
    


##  Number of Movies/TV Shows Released by Year


```python
df['release_year'] = pd.to_datetime(df['release_year'], errors='coerce').dt.year
release_counts = df['release_year'].value_counts().sort_index()
plt.figure(figsize=(12,6))
sns.lineplot(x=release_counts.index, y=release_counts.values, marker='o')
plt.title('Number of Movies/TV Shows Released by Year', fontsize=16)
plt.xlabel('Year')
plt.ylabel('Number of Releases')
plt.tight_layout()
plt.show()
```


    
![png](output_18_0.png)
    


## Movies/TV Shows per Country


```python
country_counts = df['country'].dropna().str.split(',').explode().value_counts()
plt.figure(figsize=(12,6))
sns.barplot(x=country_counts.index[:10], y=country_counts.values[:10], palette='coolwarm')
plt.xticks(rotation=90)
plt.title('Top 10 Countries with Most Netflix Movies/TV Shows', fontsize=16)
plt.xlabel('Country')
plt.ylabel('Number of Movies/TV Shows')
plt.tight_layout()
plt.show()
```

    C:\Users\ANIKET\AppData\Local\Temp\ipykernel_11708\2360791580.py:3: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `x` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(x=country_counts.index[:10], y=country_counts.values[:10], palette='coolwarm')
    


    
![png](output_20_1.png)
    


##  Heatmap of Movies by Genre and Country


```python
pivot_table = df.groupby(['genre', 'country']).size().unstack(fill_value=0)
plt.figure(figsize=(12,8))
sns.heatmap(pivot_table, cmap='YlGnBu', annot=False, fmt='d')
plt.title('Heatmap of Genres vs Countries', fontsize=16)
plt.xlabel('Country')
plt.ylabel('Genre')
plt.tight_layout()
plt.show()
```


    
![png](output_22_0.png)
    


## Conclusion:-These visualizations give you a good starting point to analyze and understand patterns in Netflix's catalog. You can adjust the code to match your dataset’s structure or explore different aspects of the data


```python

```
